﻿using System;

namespace SdetUnityTestAssignment.SortedLinkedList
{
    public interface IIterable
    {
        IIterator GetIterator();
    }
}
